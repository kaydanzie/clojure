(ns clojure-proj.core
  (:gen-class))

(defn -main
  [& args]
  (println "Hello, World!"))
