## Assignment 5
CompletetheSequence from CodeFights.com

You are given 4 first numbers in the series as a string, in which the numbers are separated by commas. Determine whether the series is arithmetic progression, geometric progression, or pseudo-fibonacci, and return the next number in the sequence.